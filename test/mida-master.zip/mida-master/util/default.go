package util

const (
	AlphaNumChars           = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
	DefaultIdentifierLength = 16 // Random identifier for each crawl
	DefaultProtocolPrefix   = "http://"
)
